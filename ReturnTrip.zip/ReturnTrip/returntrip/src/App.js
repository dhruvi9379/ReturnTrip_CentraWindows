import './App.css';
import ReturnTripForm from './components/ReturnTripChecklist';

function App() {
  return (
    <div className="App">
      <ReturnTripForm></ReturnTripForm>
    </div>
  );
}

export default App;
