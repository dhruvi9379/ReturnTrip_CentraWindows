import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import jspdf from 'jspdf';
import moment from 'moment';
import '../index.css'
import 'jspdf-autotable';


const ReturnTripForm = () => {
  const [woNumber, setWoNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [lastInstallDate, setLastInstallDate] = useState(null);
  const [reasonForReturnTrip, setReasonForReturnTrip] = useState('');
  const [requiresNewProduct, setRequiresNewProduct] = useState(false);
  const [itemDescription, setItemDescription] = useState('');
  const [photoComplete, setPhotoComplete] = useState(false);
  const [jobSignedOff, setJobSignedOff] = useState(false);
  const [returnDateRequired, setReturnDateRequired] = useState(false);
  const [returnDate, setReturnDate] = useState('');
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [completionNotes, setCompletionNotes] = useState('');
  const [productOrderedDate, setProductOrderedDate] = useState('');
  const [expectedArrivalDate, setExpectedArrivalDate] = useState('');
  const [arrangedReturnDate, setArrangedReturnDate] = useState('');
  const [attachRemakeForm, setAttachRemakeForm] = useState(false);
  const [confirmedArrivalDate, setConfirmedArrivalDate] = useState(false);
  const [productInStock, setProductInStock] = useState(false);
  const [jobCompletedBy, setJobCompletedBy] = useState('');
  const [jobCompletedDate, setJobCompletedDate] = useState('');

 
  const handleSubmit = (event) => {
  event.preventDefault();
  const doc = new jspdf();
  const formattedLastInstallDate = moment(lastInstallDate).format('DD/MM/YYYY');
  const formattedReturnDate = moment(returnDate).format('DD/MM/YYYY');

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Return Trip Checklist', 15, 20);

  doc.setFontSize(16);
  doc.text('Customer Info', 15, 35);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`W/O#:`, 20, 45);
  doc.text(`${woNumber}`, 20, 50);
  doc.text(`Customer Name:`, 130, 45);
  doc.text(`${customerName}`, 130, 50);


  doc.text(`Address:`, 20, 57);
  doc.text(`${address}`, 20, 63);
  doc.text(`Phone Number`, 130, 57);
  doc.text(`${phoneNumber}`,130, 63);


  doc.text(`Last Install Date:`, 20, 80);
  doc.text(`${formattedLastInstallDate}`, 20, 85);
  doc.text(`Reason for return trip`, 130, 80);
  doc.text(`${reasonForReturnTrip}`, 130, 85);

  doc.text(`Does this return trip require new product?`, 20, 95);
  doc.text(`${requiresNewProduct ? 'Yes' : 'No'}`, 20, 99);

  doc.text(`Item #'s & Description:`, 20, 108);
  doc.text(`${itemDescription}`, 20, 112);

  doc.text(`Photo of defects required for remakes? :  ${photoComplete ? 'Yes' : 'No'}`, 20, 125);
  doc.text(`Has the customer signed off/paid for job? :  ${jobSignedOff ? 'Yes' : 'No'}`, 20, 135);

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Return Date Info', 15, 148);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Is there a return date required? ${returnDateRequired ? 'Yes' : 'No'}`, 20, 165);
  if (returnDateRequired) {
    doc.text(`Return Date: ${formattedReturnDate}`, 20, 173);
  }
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Additional Information', 15, 185);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Additional Instructions: `, 20, 193);
  doc.text(`${additionalInstructions}`, 20, 198);
  doc.text(`Completion Notes: `, 130, 193);
  doc.text(`${completionNotes}`, 130, 198);

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Product Info', 15, 205);


doc.autoTable()
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
 

  doc.text(`Product Ordered Date:`, 20 , 215);
  doc.text(`${productOrderedDate}`, 20 , 220);

  doc.text(`Expected Arrival Date:`, 130 , 215);
  doc.text(`${expectedArrivalDate}`, 130 , 220);

  doc.text(`Arranged Return Date:`, 20, 230);
  doc.text(`${arrangedReturnDate}`, 20, 235);

  doc.text(`Attach Remake Form?`, 130, 230);
  doc.text(`${attachRemakeForm ? 'Yes' : 'No'}`, 130,  235);

  doc.text(`Confirmed Arrival Date?`, 20, 245);
  doc.text(`${confirmedArrivalDate ? 'Yes' : 'No'}`, 20, 250);

  doc.text(`Product In Stock?`, 130, 245);
  doc.text(`${productInStock ? 'Yes' : 'No'}`, 130, 250);

  doc.setFontSize(16);

 doc.setFont('helvetica', 'bold');
  doc.text('Job Completion Info', 15, 260);

  doc.setFontSize(12);
 
  doc.setFont('helvetica', 'normal');
  doc.text(`Job Completed By:`, 20,267);
  doc.text(`${jobCompletedBy}`, 20,273);

  doc.text(`Job Completed Date:`, 130 ,267);
  doc.text(`${jobCompletedDate}`, 130, 273);

  doc.save('return_trip_checklist.pdf');

};


  const handleCheckboxChange = (event) => {
    setReturnDateRequired(event.target.checked);
};

  const allowNumeric = (event) => {
    const keyCode = event.which || event.keyCode;
    const keyValue = String.fromCharCode(keyCode);
   
    if (!/^\d$/.test(keyValue)) {
      event.preventDefault(); 
    }
  };
  const allowAlpha = (event) => {
    const keyCode = event.which || event.keyCode;
    const keyValue = String.fromCharCode(keyCode);
  
    if (!/^[a-zA-Z\s]*$/.test(keyValue)) {
      event.preventDefault(); 
    }
  };
  
  
  return (
  <div className="form-container">
  <form onSubmit={handleSubmit}>
    <h1>Return Trip Checklist</h1>

    <div className="section">
      <h2>Section 1: Customer Info</h2>
      <div className="form-row">
        <label >W/O#:</label>
        <input type="text" id="woNumber" value={woNumber} onKeyDown={allowNumeric} onChange={(e) => setWoNumber(e.target.value)} placeholder='Enter Work Order number' required />
        <label >Customer Name:</label>
        <input type="text" id="customerName" value={customerName} onKeyDown={allowAlpha} onChange={(e) => setCustomerName(e.target.value)} placeholder='Enter Customer Name'  required />
      </div>

      <div className="form-row">
        <label >Address:</label>
        <input type="text" id="address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder='Enter Customer Address' required />
        <label >Phone number:</label>
        <input type="text" id="phoneNumber" maxLength={10} value={phoneNumber} onKeyDown={allowNumeric} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Enter Phone Number(only numbers)" required />
      </div>

      <div className="form-row">
        <label htmlFor="lastInstallDate">Last Install Date:</label>
        {/* <DatePicker
        selected={lastInstallDate}
        onChange={(date) => setLastInstallDate(date)}
      /> */}
        <input type="text" id="lastInstallDate" value={lastInstallDate} onChange={(e) => setLastInstallDate(e.target.value)} placeholder='Enter Last Installed Date(MM/DD/YYYY)' required />
        <label >Reason for return trip:</label>
        <input type="text" id="reasonForReturnTrip" value={reasonForReturnTrip} onChange={(e) => setReasonForReturnTrip(e.target.value)} placeholder='Enter Reason of return trip' required />
      </div>

      <div className="form-row">
        <label >Does this return trip require new product? (Yes/No):</label>
        <input type="checkbox" id="requiresNewProduct" checked={requiresNewProduct} onChange={(e) => setRequiresNewProduct(e.target.checked)} />
      </div>

      <div className="form-row">
        <label >Item #'s & Description:</label>
        <textarea id="itemDescription" value={itemDescription} onChange={(e) => setItemDescription(e.target.value)} placeholder='Enter Description' required />
      </div>

      <div className="form-row">
        <label >Photo of defects required for remakes. Complete?</label>
        <input type="checkbox" id="photoComplete" checked={photoComplete} onChange={(e) => setPhotoComplete(e.target.checked)} />
        <label >Has the customer signed off/paid for job?</label>
        <input type="checkbox" id="jobSignedOff" checked={jobSignedOff} onChange={(e) => setJobSignedOff(e.target.checked)} />
        <label >Have you given them a return date?</label>
        <input type="checkbox" id="returnDateRequired"  checked={returnDateRequired} onChange={handleCheckboxChange} />
      </div>

      { returnDateRequired === true ? <div className="form-row">
        <label>Return Date:</label>
        <input type="text" id="returnDate"  datatype="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)} placeholder='Enter Return date(MM/DD/YYYY)' required />
      </div> : null }

    </div>

    <div className="section">
      <h2>Section 2: Additional Information</h2>

      <div className="form-row">
        <label >Additional Instructions for Installer:</label>
        <textarea id="additionalInstructions" value={additionalInstructions} onChange={(e) => setAdditionalInstructions(e.target.value)} placeholder='Enter Additional Instruction'  />
        <label >Completion Notes if needed:</label>
        <textarea id="completionNotes" value={completionNotes} onChange={(e) => setCompletionNotes(e.target.value)} placeholder='Enter Completion note'/>
      </div>

    </div>

    <div className="section">
      <h2>Section 3: Admin To Complete</h2>

      <div className="form-row">
        <label >Product Ordered Date:</label>
        <input type="text" id="productOrderedDate" value={productOrderedDate} onChange={(e) => setProductOrderedDate(e.target.value)} required  placeholder='Enter Product Order Date(MM/DD/YYYY)'/>
        <label >Expected Arrival Date:</label>
        <input type="text" id="expectedArrivalDate" value={expectedArrivalDate} onChange={(e) => setExpectedArrivalDate(e.target.value)} required placeholder='Enter Expected Arrival Date(MM/DD/YYYY)'/>
      </div>
    </div>

    <div className='form-row' >
        <label>Arranged Return Date</label>
        <input type='text' id='arrangedReturnDate' value={arrangedReturnDate} onChange={(e)=>setArrangedReturnDate(e.target.value)} required placeholder='Enter Arranged Return Date(MM/DD/YYYY)'></input>

    </div>

    <div className='form-row'>
    <label>Attach Remake Form</label>
        <input type='checkbox' id='attachRemakeForm' value={attachRemakeForm} onChange={(e)=>setAttachRemakeForm(e.target.value)} required></input>
        <label>Confirmed Arrival Date</label>
        <input type='checkbox' id='confirmedArrivalDate' value={confirmedArrivalDate} onChange={(e)=>setConfirmedArrivalDate(e.target.value)} required></input>
        <label>Product in Stock</label>
        <input type='checkbox' id='productInStock' value={productInStock} onChange={(e)=>setProductInStock(e.target.value)} required></input>
    </div>

    <div className='form-row'>
        <label>Job Completed By</label>
               <select value={jobCompletedBy} onChange={(e)=>setJobCompletedBy(e.target.value)}>
          <option value={""}>Select an Option</option>
          <option value={"Meng"}>Meng</option>
          <option value={"Vaibhav"}>Vaibhav</option>
        </select>
        <label>Job Completed Date</label>
        <input type='text' id='jobCompletedDate' value={jobCompletedDate} onChange={(e)=>setJobCompletedDate(e.target.value)} placeholder='Enter Job Completion Date'></input>
    </div>

    
    <button type="submit" onClick={handleSubmit}>Submit</button>

  </form>
</div>

  );
};

export default ReturnTripForm;